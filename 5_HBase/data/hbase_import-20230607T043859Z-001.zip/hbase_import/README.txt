--Demo prepared by Atharva K from Infocepts

1) Start Hbase shell
2) Create a Table 'driver_dangerous_event'  using following command on hbase shell
>>> create 'driver_dangerous_event','events'
3) On a new linux command line put the data.csv in your home on hdfs
4) On a new linux command line give following command
>>> hbase org.apache.hadoop.hbase.mapreduce.ImportTsv -Dimporttsv.separator=,  -Dimporttsv.columns="HBASE_ROW_KEY,events:driverId,events:driverName,events:eventTime,events:eventType,events:latitudeColumn,events:longitudeColumn,events:routeId,events:routeName,events:truckId" driver_dangerous_event hdfs://localhost:9000/user/talentum/data.csv
5) Come to the hbase shell and scan the table

